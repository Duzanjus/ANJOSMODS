const help = (prefix) => {
	return `🔰---[ *MENU ANJOS-BOT* ]---🔰
┏━━━━━━━━━━━━━━━━━━━━┓
┃ *⚠️ NAO SPAM! NAO CALL!!! ⚠️*
┃   *caso ao contrario  BLOCK*
┣━━━━━━━━━━━━━━━━━━━━┛
┃⊱❥ PROPRIETÁRIO : *ANJOS*
┃⊱❥ ATIVO : *08:00-22:00 WIB*
┃⊱❥ PREFIXO : 「 ${prefix} 」
┃⊱❥ VERSÃO : 1.1
┃⊱❥ número do meu criador:wa.me/+5511932300710
┃⊱❥ LINK do meu GRUPO: ❌
┃⊱❥ *SE FOR KIBAR DEIXA OS CRÉDITOS MAN*
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 🌀𝕬𝖓𝖏𝖔𝖘 𝑩𝑶𝑻🌀
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}info
┃➢ ${prefix}owner
┃➢ ${prefix}donasi
┃➢ ${prefix}blocklist
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 🌀𝑴𝒆𝒏𝒖 𝑺𝑰𝑴𝑷𝑳𝑬S🌀
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}sticker
┃➢ ${prefix}toimg
┃➢ ${prefix}ttp
┃➢ ${prefix}tts
┃➢ ${prefix}nulis
┃➢ ${prefix}quotes
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 🌀𝑴𝒆𝒏𝒖 𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫🌀
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}tiktod
┃➢ ${prefix}ytmp3
┣━━━━━━━━━━━━━━━━━━━━┛
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 🌀𝑴𝒆𝒏𝒖 𝑮𝑨𝑩𝑼𝑻𝒁🌀
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}apakah
┃➢ ${prefix}kapankah
┃➢ ${prefix}bisakah
┃➢ ${prefix}hobby
┃➢ ${prefix}watak
┃➢ ${prefix}rate
┃➢ ${prefix}truth
┃➢ ${prefix}dare
┣━━━━━━━━━━━━━━━━━━━━┛
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 🌀𝑴𝒆𝒏𝒖 𝑴𝑬𝑴𝑬🌀
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}meme
┃➢ ${prefix}memeindo
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 🌀𝑴𝒆𝒏𝒖 𝑮𝑹𝑶𝑼𝑷🌀
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}admin
┃➢ ${prefix}welcome [1/0]
┃➢ ${prefix}add
┃➢ ${prefix}kick
┃➢ ${prefix}promote
┃➢ ${prefix}demote
┃➢ ${prefix}tagall
┃➢ ${prefix}tagall2
┃➢ ${prefix}tagall3
┃➢ ${prefix}linkgrup
┃➢ ${prefix}leave
┃➢ ${prefix}hidetag
┃➢ ${prefix}simih [1/0]
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 🌀𝑴𝒆𝒏𝒖 𝑪𝑶𝑴𝑳𝑰🌀 ✖[ERRO]✖
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}randomhentong
┃➢ ${prefix}randomloli
┃➢ ${prefix}nsfwblowjob
┃➢ ${prefix}nsfwneko
┃➢ ${prefix}nsfwtrap
┣━━━━━━━━━━━━━━━━━━━━┛
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 🌀𝑴𝒆𝒏𝒖 𝑶𝑻𝑯𝑬𝑹🌀
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}ssweb
┃➢ ${prefix}simi
┃➢ ${prefix}ocr
┃➢ ${prefix}wait
┃➢ ${prefix}tiktokstalk
┃➢ ${prefix}hilih
┃➢ ${prefix}ytstalk
┣━━━━━━━━━━━━━━━━━━━━┛
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 🌀𝑴𝒆𝒏𝒖 𝑴𝑨𝑲𝑬𝑹🌀
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}hartatahta
┃➢ ${prefix}pornhub
┃➢ ${prefix}thundername
┃➢ ${prefix}galaxytext
┃➢ ${prefix}glitchtext
┃➢ ${prefix}partytext
┃➢ ${prefix}bucintext
┃➢ ${prefix}glowtext
┃➢ ${prefix}lovetext
┃➢ ${prefix}gugeltext
┣━━━━━━━━━━━━━━━━━━━━┛
┃ 🌀𝑴𝒆𝒏𝒖 𝑶𝑾𝑵𝑬𝑹🌀
┣━━━━━━━━━━━━━━━━━━━━┓
┃➢ ${prefix}setprefix
┃➢ ${prefix}bc
┃➢ ${prefix}clearall
┃➢ ${prefix}clone
┣━━━━━━━━━━━━━━━━━━━━┛
┃⟪ CRIADO POR BY *ANJOS MODS* ⟫
┣━━━━━━━━━━━━━━━━━━━━┓

             ╲    ╱    ● ᏴϴͲ●ᎷᎬΝႮ●
       ╱▔▔▔▔▔╲       Autor    : ANJOS BOT
      ┃┈▇┈┈▇┈┃      
╭╮┣━━━━━━┫╭╮    
┃┃┃┈┈┈┈┈┈┃┃┃    
╰╯┃┈┈┈┈┈┈┃╰╯
      ╰┓┏━━┓┏╯
         ╰╯      ╰╯
`
}

exports.help = help
