const donasi = () => {
	return `╔════════════════════
║ *DOE PELO DONO OU PELO PICPAY*
╠════════════════════
║╭──❉ *DONASI BOS* ❉─────
║│➸ *DONO DO BOT:*: +5511932300710
║│➸ *GOPAY*: @eduardo.anjos03
║╰──────────────────
╠════════════════════
║         ANJOS
║  ▌│█║▌║▌║║▌║▌║█│▌
║  ▌│█║▌║▌║║▌║▌║█│▌
║         ANJOS
╠════════════════════
║ _*feito por BY Anjos mods*_
╚════════════════════
`
}

exports.donasi = donasi
